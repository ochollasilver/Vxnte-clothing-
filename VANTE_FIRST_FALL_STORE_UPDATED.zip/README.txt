VANTE — THE FIRST FALL STORE
The supplied white and black VANTE product images are included in /images.

To go live:
1. Upload this folder to a web host.
2. Connect a domain.
3. Connect an eligible adult/business payment account and a secure server-side M-PESA/Daraja integration.
4. Never put payment API secrets directly in the front-end files.
5. Add delivery rules, stock quantities, and your business contact details.

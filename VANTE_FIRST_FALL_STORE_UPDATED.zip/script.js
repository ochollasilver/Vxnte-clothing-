let bag=JSON.parse(localStorage.getItem("vanteBag")||"[]");
const cart=document.getElementById("cart"),shade=document.getElementById("shade");
function render(){document.getElementById("count").textContent=bag.length;let box=document.getElementById("items");if(!bag.length){box.innerHTML='<p style="font-size:12px;color:#777;padding:20px 0">Your bag is empty.</p>'}else{box.innerHTML=bag.map((x,i)=>`<div class="row"><div><strong>${x.name}</strong><br>Size: ${x.size}<br>KSh ${x.price.toLocaleString()}<button onclick="removeItem(${i})">Remove</button></div><span>KSh ${x.price.toLocaleString()}</span></div>`).join("")}document.getElementById("total").textContent="KSh "+bag.reduce((a,x)=>a+x.price,0).toLocaleString()}
function save(){localStorage.setItem("vanteBag",JSON.stringify(bag));render()}
function open(){cart.classList.add("open");shade.classList.add("show");render()}
function close(){cart.classList.remove("open");shade.classList.remove("show")}
document.getElementById("bagBtn").onclick=open;document.getElementById("close").onclick=close;shade.onclick=close;
document.querySelectorAll(".add").forEach(b=>b.onclick=()=>{let product=b.closest(".product");bag.push({name:b.dataset.name,size:product.querySelector(".size").value,price:+b.dataset.price});save();open()});
window.removeItem=i=>{bag.splice(i,1);save()};
document.getElementById("checkout").onclick=()=>{if(!bag.length){alert("Your bag is empty.");return}alert("To order, call VANTE on 0704 394 176. Your selected items are shown in your bag.");};
render();